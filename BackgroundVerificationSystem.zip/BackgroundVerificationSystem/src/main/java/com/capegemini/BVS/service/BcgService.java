package com.capegemini.BVS.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capegemini.BVS.dto.EmployeeDocumentDto;
import com.capegemini.BVS.dto.VerificationDto;
import com.capegemini.BVS.exe.BackgroundVerificationController;

public class BcgService {
	public void getByName() {
		System.out.println("------------------------------------------------------------------------------------------");
		File logfile = new File("C:\\Users\\user\\Documents\\workspace-sts-3.9.9.RELEASE\\Rahul Kumar\\BackgroundVerificationSystem\\src\\main\\resources\\doc.txt");
		FileInputStream fis=null;
		HashMap<Integer, EmployeeDocumentDto> object1=null;
		try {
			fis = new FileInputStream(logfile);
			
			ObjectInputStream in = new ObjectInputStream(fis);
			
			object1 = (HashMap<Integer, EmployeeDocumentDto>)in.readObject();
			if(object1==null) {
				System.out.println("No information stored");
				new BackgroundVerificationController().logging();
			}
			for(Map.Entry obj: object1.entrySet()) {
				EmployeeDocumentDto object = (EmployeeDocumentDto)obj.getValue();
				System.out.println(object.getEmpId()+" "+object.getEmpName());
			}
			
			in.close();
			fis.close();
//			new BackgroundVerificationController().logging();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void approveStatus(int id) {
		System.out.println("------------------------------------------------------------------------------------------");
		File logfile = new File("C:\\Users\\user\\Documents\\workspace-sts-3.9.9.RELEASE\\Rahul Kumar\\BackgroundVerificationSystem\\src\\main\\resources\\doc.txt");
		FileInputStream fis=null;
		FileOutputStream fos=null;
		HashMap<Integer, EmployeeDocumentDto> object1=null;
		try {
			fis = new FileInputStream(logfile);
			
			ObjectInputStream in = new ObjectInputStream(fis);
			
			object1 = (HashMap<Integer, EmployeeDocumentDto>)in.readObject();
			
			EmployeeDocumentDto object = (EmployeeDocumentDto)object1.get(id);
			VerificationDto doc = object.getVerificationDto();
			doc.setStatus("Accepted");
			object.setVerificationDto(doc);
			object1.put(id, object);
			in.close();
			fis.close();
			fos = new FileOutputStream(logfile);
			ObjectOutputStream out = new ObjectOutputStream(fos);
			out.writeObject(object1);
			out.close();
			fos.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Accepted");
		new BackgroundVerificationController().logging();
	}
	
	
	public void getDocument(int id) {
		Scanner scn = new Scanner(System.in);
		System.out.println("------------------------------------------------------------------------------------------");
		File logfile = new File("C:\\Users\\user\\Documents\\workspace-sts-3.9.9.RELEASE\\Rahul Kumar\\BackgroundVerificationSystem\\src\\main\\resources\\doc.txt");
		FileInputStream fis=null;
		HashMap<Integer, EmployeeDocumentDto> object1=null;
		try {
			fis = new FileInputStream(logfile);
			
			ObjectInputStream in = new ObjectInputStream(fis);
			
			object1 = (HashMap<Integer, EmployeeDocumentDto>)in.readObject();
			for(Map.Entry obj: object1.entrySet()) {
				EmployeeDocumentDto object = (EmployeeDocumentDto)obj.getValue();
				if(id==object.getEmpId()) {
					String data = object.getDocData();
					System.out.println("Document Data : "+data);
					System.out.println("Enter 1 for reject and 2 for accept :");
					int choice = scn.nextInt();
					if(choice==2) {
						new BcgService().approveStatus(id);
					}
					else
					{
						new BcgService().rejectStatus(id);
					}
				}
			}
			
			in.close();
			fis.close();
//			new BackgroundVerificationController().logging();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	public void rejectStatus(int id) {
		System.out.println("------------------------------------------------------------------------------------------");
		File logfile = new File("C:\\Users\\user\\Documents\\workspace-sts-3.9.9.RELEASE\\Rahul Kumar\\BackgroundVerificationSystem\\src\\main\\resources\\doc.txt");
		FileInputStream fis=null;
		FileOutputStream fos=null;
		HashMap<Integer, EmployeeDocumentDto> object1=null;
		try {
			fis = new FileInputStream(logfile);
			
			ObjectInputStream in = new ObjectInputStream(fis);
			
			object1 = (HashMap<Integer, EmployeeDocumentDto>)in.readObject();
			
			EmployeeDocumentDto object = (EmployeeDocumentDto)object1.get(id);
			VerificationDto doc = object.getVerificationDto();
			doc.setStatus("Rejected");
			object.setVerificationDto(doc);
			object1.put(id, object);
			in.close();
			fis.close();
			fos = new FileOutputStream(logfile);
			ObjectOutputStream out = new ObjectOutputStream(fos);
			out.writeObject(object1);
			out.close();
			fos.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Rejected");
		new BackgroundVerificationController().logging();
	}
}
