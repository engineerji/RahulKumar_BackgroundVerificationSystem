package com.capegemini.BVS.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capegemini.BVS.dto.EmployeeDocumentDto;
import com.capegemini.BVS.dto.LoginDto;
import com.capegemini.BVS.dto.VerificationDto;
import com.capegemini.BVS.exe.BackgroundVerificationController;

public class EmployeeService {
	Scanner scn = new Scanner(System.in);
	
	public void viewStatus(int empid) {
		System.out.println("------------------------------------------------------------------------------------------");
		File logfile = new File("C:\\Users\\user\\Documents\\workspace-sts-3.9.9.RELEASE\\Rahul Kumar\\BackgroundVerificationSystem\\src\\main\\resources\\doc.txt");
		FileInputStream fis=null;
		HashMap<Integer, EmployeeDocumentDto> object1=null;
		try {
			fis = new FileInputStream(logfile);
			
			ObjectInputStream in = new ObjectInputStream(fis);
			
			object1 = (HashMap<Integer, EmployeeDocumentDto>)in.readObject();
			
			if(object1.get(empid)!=null) {
				EmployeeDocumentDto edd = object1.get(empid);
				
				VerificationDto vDto = edd.getVerificationDto();
				if(empid==edd.getEmpId()) {
					System.out.println("Status is :"+vDto.getStatus());
				}
			}
			else {
				System.out.println("No Document is stored");
				new BackgroundVerificationController().logging();
			}
			
			in.close();
			fis.close();
			new BackgroundVerificationController().logging();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	//empName, int docId, String docType, String docData
	public void storeDocument(LoginDto logDto) {
		//System.out.println(ld.getEmpId()+""+ld.getRoleId());
		System.out.println();
		System.out.println("Enter the Employee Name :");
		String empName = scn.nextLine();
		System.out.println("Enter the Document Id :");
		int docId = scn.nextInt();
		System.out.println("Enter the Document Type 1. Id\n2. HSC\n3. SSC\n4. Photo ");
		String docType = scn.next();
		System.out.println("Enter the document data :");
		String docData = scn.next();
		
		//System.out.println("Success");
		int verid = logDto.getEmpId()*10+1;
		//DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/YYYY");  
		LocalDate now = LocalDate.now();
		LocalDate tomorrow = now.plusDays(2);
	    //System.out.println(tomorrow);
		VerificationDto verifyDto = new VerificationDto(verid,now,tomorrow,"pending");
		System.out.println(verifyDto.getStatus());
	
		EmployeeDocumentDto empDocDto = new EmployeeDocumentDto(logDto.getEmpId(), empName, docId, docType, docData, verifyDto);
		
		
		File logfile = new File("C:\\Users\\user\\Documents\\workspace-sts-3.9.9.RELEASE\\Rahul Kumar\\BackgroundVerificationSystem\\src\\main\\resources\\doc.txt");
		FileInputStream fis=null;
		HashMap<Integer, EmployeeDocumentDto> object1=null;
		FileOutputStream fos = null;
		try {
			fis = new FileInputStream(logfile);
			
			ObjectInputStream in = new ObjectInputStream(fis);
			
			object1 = (HashMap<Integer, EmployeeDocumentDto>)in.readObject();
			
			object1.put(empDocDto.getEmpId(),empDocDto);	
			
			in.close();
			fis.close();
			
			
			
			fos = new FileOutputStream(logfile);
			ObjectOutputStream out = new ObjectOutputStream(fos);
			out.writeObject(object1);
			
			out.close();
			fis.close();
			System.out.println("Document stored");
			new BackgroundVerificationController().logging();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
